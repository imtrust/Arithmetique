import logging
import os
import socket
import socketserver
import struct

from flask import Flask, abort, request, session, render_template
from werkzeug.serving import BaseWSGIServer

app = Flask(__name__)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.set_inheritable(True)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
#log = logging.getLogger('werkzeug')
#log.disabled = True # on ne veut pas les requetes HTTP dans la console, mais les affichages (print)

print("toto")

@app.route('/hello')
def hello():
    print("Hello dans la console juste avant de dire Hello dans le navigateur !")
    return "Hello, ce qui signifie Bonjour en anglais !"

@app.route('/')
def accueil():
    return render_template("accueil.html")

@app.route('/bye')
def bye():
    return "Bye-bye !"

# Bloc servant à fermer proprement la connexion au serveur à chaque fois que le fichier est executé
if __name__ == "__main__":
    try:
        bind_to = ('127.0.0.1', 5000)
        sock.bind(bind_to)
        sock.listen()
        sock_fd = sock.fileno()
        base_wsgi = BaseWSGIServer(
            *bind_to, app, fd=sock_fd)

        base_wsgi.serve_forever()

    finally:
        if not sock._closed:
            msg = "Socket not closed, closing."
            sock.close()
        else:
            msg = "Socket already closed."
        print(msg)

app.run(Debug=True)